# Axiom — Human Resource Management System

**Odoo × NMIT Bangalore Hackathon 2026** · Problem statement: *AXIOM – HRMS*

Axiom gives small organisations one clean, modern system for the whole workday:
attendance, leave and payroll — with two purpose-built experiences (Employee and HR/Admin).

## Problem being solved

Teams run HR on spreadsheets and chat messages: attendance is guessed, leave balances
live in someone's head, and payroll questions turn into email threads. Axiom replaces
that with a transparent, self-service HRMS — employees see their own data, HR gets a
command center, and everything is ready for a real REST backend.

## Main features

- **Landing + auth** — signup with validation, JWT login (email normalised, passwords
  hashed with Werkzeug), role-based redirect, deactivated accounts blocked
- **Employee workspace** — dashboard, one-click check-in/check-out (auto half-day < 4h),
  attendance history, leave application with live balance + overlap checks, read-only
  payroll & payslips, editable profile (phone/address/photo only)
- **HR command center** — live presence stats (present/absent/half-day/leave) + department
  breakdown, weekly attendance grid, employee management (**add / search / view / edit /
  deactivate**), leave approvals with comments, salary structure editing, activity feed
- **Notifications** — stored in the database with persistent read/unread state:
  leave submitted → HR notified, decision → employee notified, unread badge in the bell
- **Real data only** — every number on every page is computed from the database via the
  Flask API. If the backend is down the UI shows
  *"Unable to connect to server. Please try again."* — it never silently displays mock data
  (an offline demo mode exists but must be explicitly enabled with `?mock`)

## Architecture

```
frontend/   HTML5 · CSS3 · vanilla JS · Bootstrap (vendored)   →  js/api.js is the single data layer
backend/    Python · Flask · Flask-SQLAlchemy · SQLite · JWT · Flask-CORS
database/   schema.sql + seed.sql (mirror of the ORM)
tests/      pytest suite (54 tests) using Flask's test client
docs/       setup · architecture · full API contract
```

Details: [docs/architecture.md](docs/architecture.md) · Full endpoint reference:
[docs/api-contract.md](docs/api-contract.md)

## Technology stack

| Layer | Tech |
|---|---|
| Frontend | HTML5, CSS3, JavaScript, Bootstrap 5 (downloaded locally — works offline) |
| Backend | Python 3, Flask, Flask blueprints |
| Data | Flask-SQLAlchemy ORM, SQLite (hackathon dev) |
| Auth | JWT (PyJWT), Werkzeug password hashing, role guards |
| Misc | Flask-CORS, python-dotenv, pytest |

## Project structure

```
odoo-nmit-hackathon/
├── frontend/               # existing UI (source of truth for the API contract)
│   ├── *.html              # landing, login, signup, dashboards, profile, attendance, leave, payroll
│   ├── css/ js/ assets/
│   └── js/api.js           # ← the ONLY file that talks to the backend (mock/API switch)
├── backend/
│   ├── app.py config.py extensions.py seed.py
│   ├── models/             # User, Employee, Attendance, Leave, Payroll, Activity
│   ├── routes/             # auth, employees, attendance, leaves, payroll, hr, activities
│   ├── utils/              # JWT/auth guards, validators, JSON responses
│   ├── requirements.txt · .env.example
├── database/               # schema.sql, seed.sql
├── tests/                  # pytest suite
└── docs/                   # setup, architecture, API contract
```

## Install & run

### Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py                                        # tables + demo data seed automatically
# → http://localhost:5000   (health: /api/health)
```

### Frontend

```bash
cd frontend
python -m http.server 8000
# → open http://localhost:8000
```

Full guide (troubleshooting, reset, tests): [docs/setup.md](docs/setup.md)

## Demo credentials

| Role | Email | Password |
|---|---|---|
| HR / Admin | `priya@axiom.com` | `password123` |
| Employee | `arjun@axiom.com` | `password123` |

## How the frontend communicates with the backend

All page scripts call the `api` object in `frontend/js/api.js`; it attaches
`Authorization: Bearer <JWT>` to every request and expects bare-JSON success payloads
plus `{"success": false, "message": …}` errors. The single switch at the top of the file:

```js
const API_CONFIG = {
  baseUrl: 'http://localhost:5000',
  useMock: false,            // USE_MOCK_DATA — default false → real API → real database
};
```

- **No silent fallback**: backend unreachable → *"Unable to connect to server. Please try
  again."*; 401 → *"Session expired. Please log in again."*; 403 → *"You do not have
  permission to perform this action."*; 404 → *"Requested record was not found."*;
  5xx → *"Something went wrong on the server."*; 409/validation errors show the server's
  actual reason.
- Offline demo mode is dev-only and explicit: `?mock` in the URL or
  `localStorage.axiom_use_mock = '1'` (`?api` / `'0'` forces real mode).

## Running the tests

```bash
pip install -r backend/requirements.txt
pytest tests/ -v          # 62 tests: auth, employees, attendance, leaves, payroll,
                          # notifications, restart-persistence, email-normalisation
```

## Roadmap

- [x] Frontend (10 pages, both roles, responsive, loading/empty/error states)
- [x] Flask REST API — every endpoint the frontend calls
- [x] SQLite schema + seed, JWT auth, role guards, notifications with read/unread, 62 passing tests, docs
- [ ] Production hardening (rate limiting, refresh tokens, Postgres, file uploads to disk/S3)
- [ ] Payslip PDF export & email notifications
